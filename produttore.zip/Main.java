package produttore;

import java.util.Random;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		 Scanner scanner = new Scanner(System.in);
	        Random random = new Random();

	        System.out.print("Inserisci il numero di thread (T): ");
	        int t = scanner.nextInt();

	        System.out.print("Inserisci il valore massimo (N): ");
	        int n = scanner.nextInt();

	        Thread[] threads = new Thread[t];
	        ThreadCreatore[] threadCreatori = new ThreadCreatore[t];

	        // Creiamo i thread e assegniamo a ciascuno un valore X casuale tra 0 e N
	        for (int i = 0; i < t; i++) {
	            int x = random.nextInt(n + 1); // Valore X casuale tra 0 e N
	            threadCreatori[i] = new ThreadCreatore(x);
	            threads[i] = new Thread(threadCreatori[i], "Thread-" + i);
	        }

	        // Avviamo tutti i thread
	        for (int i = 0; i < t; i++) {
	            threads[i].start();
	        }

	        // Thread principale controlla periodicamente lo stato dei thread
	        boolean allCompleted = false;
	        while (!allCompleted) {
	            allCompleted = true;

	            for (int i = 0; i < t; i++) {
	                if (threads[i].isAlive()) {
	                    allCompleted = false;
	                    System.out.println(threads[i].getName() + " è attivo, conteggio attuale: " + threadCreatori[i].getCurrent());
	                } else if (threadCreatori[i].isCompleted()) {
	                    System.out.println(threads[i].getName() + " COMPLETATO");
	                }
	            }

	            // Aspetta un secondo prima di controllare nuovamente lo stato dei thread
	            try {
	                Thread.sleep(1000);
	            } catch (InterruptedException e) {
	                e.printStackTrace();
	            }
	        }

	        // Attendere il completamento di tutti i thread
	        for (int i = 0; i < t; i++) {
	            try {
	                threads[i].join();
	            } catch (InterruptedException e) {
	                e.printStackTrace();
	            }
	        }

	        System.out.println("TUTTI I THREAD COMPLETATI");
	    }
	

}
