package produttore;

public class ThreadCreatore implements Runnable {
	    private int max;
	    private int current;
	    private boolean completed;
	    
	    public ThreadCreatore(int max) {
	        this.max = max;
	        this.current = 0;
	        this.completed = false;
	    }

	    public int getCurrent() {
	        return current;
	    }

	    public boolean isCompleted() {
	        return completed;
	    }

	    @Override
	    public void run() {
	        while (current < max) {
	            try {
	                Thread.sleep(120); // Ogni thread aspetta 120ms tra ogni conteggio
	            } catch (InterruptedException e) {
	                e.printStackTrace();
	            }
	            current++; // Incrementa il valore corrente fino a raggiungere il massimo
	        }
	        completed = true; // Segna il thread come completato
	    }
	}
